/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yyang
 */
public class Task1 {
    
    public static void main(String[] args) {
        BufferedReader br = null;
        PrintWriter pw = null;
        try {
            br = new BufferedReader(new FileReader("input.txt"));
            pw = new PrintWriter("output.txt");
            String line;
            //read line by line in "input.txt"
            while((line = br.readLine())!=null){
                //reversely iterate the chars in the line
                for(int i =line.length()-1;i>=0;--i){
                    //obtain the char at the current index
                    char currentChar = line.charAt(i);
                    //check if the current char is a letter
                    if(Character.isLetter(currentChar)){
                        //convert the current to uppercase and write it to the output file.
                        pw.print(Character.toUpperCase(currentChar));
                    }
                }
                pw.println();
            }
        }  catch (IOException ex) {
            Logger.getLogger(Task1.class.getName()).log(Level.SEVERE, null, ex);
        } finally{
            //code in the finally block will alway be executed 
            if(br != null){
                try {
                    br.close();
                } catch (IOException ex) {
                    Logger.getLogger(Task1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(pw != null){
                pw.close();
            }
        }
    }
    
}
