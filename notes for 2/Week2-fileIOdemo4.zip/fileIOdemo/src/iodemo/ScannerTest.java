package iodemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ScannerTest {
    public static void main(String args[]){
        //Scanner sc = new Scanner (System.in);
        
        String str="abc,,,,,dec";
        Scanner sc = new Scanner(str);
        sc.useDelimiter(",,*");
        while(sc.hasNext()){
            System.out.println(sc.next());
        }

        //sc.useDelimiter("a* | b*");
        /*
        System.out.print ("Enter first int: ");
        while (sc.hasNextInt())
        {
                int i = sc.nextInt();
                System.out.println("You entered " + i);
                System.out.print ("Enter another int: ");
        }

        */
    }
}
