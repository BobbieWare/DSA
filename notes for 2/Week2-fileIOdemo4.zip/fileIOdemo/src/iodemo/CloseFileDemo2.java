package iodemo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class CloseFileDemo2 {
    public static void main(String[] args) throws FileNotFoundException{
        PrintWriter outputStream;
        FileOutputStream fos=new FileOutputStream("out2.txt");
        outputStream = new PrintWriter(fos);
        for (int count = 100; count <= 200; count++)
        {
            outputStream.println(count);
        }
        outputStream.flush();
        //outputStream.close();
        outputStream = new PrintWriter(fos);
        for (int count = 300; count <= 400; count++)
        {
            outputStream.println(count);
        }
        outputStream.close();

    }
}
