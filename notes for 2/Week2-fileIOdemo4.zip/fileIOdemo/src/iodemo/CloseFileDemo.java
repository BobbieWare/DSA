package iodemo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class CloseFileDemo {
    public static void main(String[] args) throws FileNotFoundException{
        PrintWriter outputStream;
        FileOutputStream fos=new FileOutputStream("out.txt");
        outputStream = new PrintWriter(fos);
        for (int count = 1; count <= 3; count++)
        {
            outputStream.println(count);
        }
        outputStream.close();
        outputStream = new PrintWriter(fos);
        for (int count = 5; count <= 8; count++)
        {
            outputStream.println(count);
        }
        outputStream.close();

    }
}
